﻿using Inventario.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Inventario.ViewModels
{
    public class ItemViewModel
    {
        public List<Item> items { get; set; }  
    }
}