﻿using Microsoft.Owin;
using Owin;
using Microsoft.Extensions.DependencyInjection;
using MediatR;

[assembly: OwinStartupAttribute(typeof(Inventario.Startup))]
namespace Inventario
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);

        }

        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddScoped<ApplicationDbContext>(sp => new ApplicationDbContext());
            //services.AddScoped<IUnitOfWork>(sp => new UnitOfWork.UnitOfWork(new ApplicationDbContext()));

            //services.AddMediatR(typeof(Startup).Assembly);
            //var serviceProvider = new ServiceCollection().AddMediatR(typeof(Startup)).BuildServiceProvider();

            //IMediator mediator = serviceProvider.GetService<IMediator>();
            //services.AddMediatR(typeof(Startup));
            
            //var resolver = new NinjectResolver();
            //DependencyResolver.SetResolver(resolver);
            
        }

    }


}
