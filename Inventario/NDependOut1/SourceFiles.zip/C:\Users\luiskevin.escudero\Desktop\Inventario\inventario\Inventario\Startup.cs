﻿using Microsoft.Owin;
using Owin;
using Microsoft.Extensions.DependencyInjection;
using MediatR;
using Inventario.Models;
using Inventario.UnitOfWork;
using Inventario.App_Start;
using System.Web.Mvc;

[assembly: OwinStartupAttribute(typeof(Inventario.Startup))]
namespace Inventario
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);

        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMediatR(typeof(Startup));
            //services.AddScoped<ApplicationDbContext>(sp => new ApplicationDbContext());
            //services.AddScoped<IUnitOfWork>(sp => new UnitOfWork.UnitOfWork(new ApplicationDbContext()));

            //services.AddMediatR(typeof(Startup).Assembly);
            //var serviceProvider = new ServiceCollection().AddMediatR(typeof(Startup)).BuildServiceProvider();

            //IMediator mediator = serviceProvider.GetService<IMediator>();
            //services.AddMediatR(typeof(Startup));

            //var resolver = new NinjectResolver();
            //DependencyResolver.SetResolver(resolver);

        }

    }


}
